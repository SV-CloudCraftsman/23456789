package com.cap.register;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagefactor.PageFactor;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Register_StepDefinition {
	public WebDriver driver;
	public PageFactor page;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\bnagasun\\Desktop\\chrome\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	 @After
     public void closee()
     {
         driver.quit();
     }
	 @Given("^user is on Registration from page$")
	 public void user_is_on_Registration_from_page() throws Throwable {
	     driver.get("C:\\Users\\bnagasun\\Desktop\\New folder\\registrationForm_jobsWorld\\RegistrationForm.html");
	     page=new PageFactor(driver);
	     Thread.sleep(3000);
	 }

	 @Then("^check if title of the page is Welcome to JobsWorld$")
	 public void check_if_title_of_the_page_is_Welcome_to_JobsWorld() throws Throwable {
		 String title=driver.getTitle();

		 Assert.assertEquals("Welcome to JobsWorld", title);


	   
	 }

	 @When("^user enters Invalid id$")
	 public void user_enters_Invalid_id() throws Throwable {
		 page.setUserid("");

		   page.setSubmitbtn();
	  
	  
	 }

	 @Then("^displays 'User Id should not be empty / length be between (\\d+)$")
	 public void displays_User_Id_should_not_be_empty_length_be_between(int arg1) throws Throwable {
		 String id=driver.switchTo().alert().getText();

		  Assert.assertEquals("User Id should not be empty / length be between 5 to 12", id);

		  driver.switchTo().alert().accept();

		  Thread.sleep(2000);
	 }

	 @When("^user enters invalid password$")
	 public void user_enters_invalid_password() throws Throwable {
		 page.setUserid("46005059");

		  page.setPass("");

		  page.setSubmitbtn();
	 }

	 @Then("^display 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
	 public void display_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		 String password=driver.switchTo().alert().getText();

		  Assert.assertEquals("Password should not be empty / length between 7 to 12", password);

		  driver.switchTo().alert().accept();

		  Thread.sleep(2000);
	 }

	 @When("^user enters invalid name$")
	 public void user_enters_invalid_name() throws Throwable {
		 page.setUserid("46005059");

		  page.setPass("bala010");

		  page.setName("");

		  page.setSubmitbtn();
	 }

	 @Then("^display 'Name should not be empty and must have alphabet characters only'$")
	 public void display_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		 String uname=driver.switchTo().alert().getText();

		  Assert.assertEquals("Name should not be empty and must have alphabet characters only", uname);

		  driver.switchTo().alert().accept();

		 // Thread.sleep(2000);

		 }
	 

	 @When("^user enters invalid address$")
	 public void user_enters_invalid_address() throws Throwable {
		
		 page.setUserid("46005059");

		  page.setPass("Bala009");

		  page.setName("bala");

		  page.setAddress("");

		page.setSubmitbtn();

	 }

	 @Then("^display 'User address must have alphanumeric characters only'$")
	 public void display_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		  String address=driver.switchTo().alert().getText();

		  Assert.assertEquals("User address must have alphanumeric characters only", address);

		  driver.switchTo().alert().accept();

		 // Thread.sleep(2000);
	 }
	 @When("^user enters invalid country$")
	 public void user_enters_invalid_country() throws Throwable {
		 page.setUserid("46005059");

		 page.setPass("Bala009");

		 page.setName("Bala");

		 page.setAddress("cbekovai");

		 page.setCountry("");

		 page.setSubmitbtn();
	 }

	 @Then("^display 'Select your country from the list'$")
	 public void display_Select_your_country_from_the_list() throws Throwable {
		  String country=driver.switchTo().alert().getText();

		  Assert.assertEquals("Select your country from the list", country);

		  driver.switchTo().alert().accept();

		 // Thread.sleep(2000);
	 }

	 @When("^user enters invalid zip code$")
	 public void user_enters_invalid_zip_code() throws Throwable {
		 page.setUserid("46005059");

		  page.setPass("Bala009");

		  page.setName("Bala");

		  page.setAddress("cbeKovai");

		 page.setCountry("India");

		  page.setZip("");

		page.setSubmitbtn();
	 }

	 @Then("^display 'ZIP code must have numeric characters only'$")
	 public void display_ZIP_code_must_have_numeric_characters_only() throws Throwable {
		 String zipcode=driver.switchTo().alert().getText();

		  Assert.assertEquals("ZIP code must have numeric characters only", zipcode);

		  driver.switchTo().alert().accept();

		  Thread.sleep(2000);
	 }

	 @When("^user enters invalid email$")
	 public void user_enters_invalid_email() throws Throwable {
		page.setUserid("123456");

		page.setPass("balaa10");

		 page.setName("bala");

		 page.setAddress("cbekovai");

		 page.setCountry("India");

		  page.setZip("641043");

		  page.setMail("");

		page.setSubmitbtn();
	 }

	 @Then("^displays 'You have entered an invalid email address!'$")
	 public void displays_You_have_entered_an_invalid_email_address() throws Throwable {
		 String mail=driver.switchTo().alert().getText();

		 Assert.assertEquals("You have entered an invalid email address!", mail);

		 driver.switchTo().alert().accept();

		 Thread.sleep(2000);
	 }

	 @When("^user doesnot select gender$")
	 public void user_doesnot_select_gender() throws Throwable {
		 page.setUserid("46005059");

		 page.setPass("balaa10");

		 page.setName("bala");

		 page.setAddress("cbekovai");

		 page.setCountry("India");

		 page.setZip("641043");

		 page.setMail("bala@gmail.com");

		 page.setSex("");

		 page.setSubmitbtn();
	 }

	 @Then("^displays 'Please Select gender'$")
	 public void displays_Please_Select_gender() throws Throwable {
		 String gender=driver.switchTo().alert().getText();

		 Assert.assertEquals("Please Select gender", gender);

		 driver.switchTo().alert().accept();

		 Thread.sleep(2000);
	 }

	 @When("^user select defalut Language as English$")
	 public void user_select_defalut_Language_as_English() throws Throwable {
		 page.setUserid("46005059");

		 page.setPass("balaa10");

		 page.setName("bala");

		 page.setAddress("cbekovai");

		 page.setCountry("India");

		 page.setZip("641043");

		 page.setMail("bala@gmail.com");

		 page.setSex("male");

		 page.setLanguage("English");

		 page.setSubmitbtn();
	 }

	 @When("^user enters valid registration details$")
	 public void user_enters_valid_registration_details() throws Throwable {
		 page.setUserid("123456");

		 page.setPass("balaa10");

		 page.setName("bala");

		 page.setAddress("cbekovai");

		 page.setCountry("India");

		 page.setZip("641043");

		 page.setMail("bala@gmail.com");

		 page.setSex("male");

		 page.setLanguage("English");

		 page.setSubmitbtn();


	 }

	 @Then("^displays 'Registartion completed'$")
	 public void displays_Registartion_completed() throws Throwable {
	     
	 }
}