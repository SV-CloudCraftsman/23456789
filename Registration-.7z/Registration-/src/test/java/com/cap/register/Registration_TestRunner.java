package com.cap.register;



import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = {"C:\\Users\\bnagasun\\Desktop\\New folder\\registrationForm_jobsWorld\\src\\test\\resources\\features\\registrationform.feature"},
       glue= {"com.cap.register"},
       dryRun=false,
       monochrome=true,
       strict=false,
       format = { "pretty", "html:test-output" }
       // tags= {"@SmokeTest,@RegressionTest","~@End2End"},
      //plugin = {"html:target/Destination"}
       )
public class Registration_TestRunner {

}
