
package com.cg.pagefactor;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.CacheLookup;

import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;

public class PageFactor {

	WebDriver Driver;

	@FindBy(name = "userid")

	@CacheLookup

	WebElement userid;

	@FindBy(name = "passid")

	@CacheLookup

	WebElement pass;

	@FindBy(name = "username")

	@CacheLookup

	WebElement name;

	@FindBy(name = "address")

	@CacheLookup

	WebElement address;

	@FindBy(name = "country")

	@CacheLookup

	WebElement country;

	@FindBy(name = "zip")

	@CacheLookup

	WebElement zip;

	@FindBy(name = "email")

	@CacheLookup

	WebElement mail;

	@FindBy(xpath = "//input[@value='Female']")

	@CacheLookup

	WebElement sex;

	@FindBy(xpath = "//input[@name='en']")

	@CacheLookup

	WebElement language;

	@FindBy(name = "submit")

	@CacheLookup

	WebElement submitbtn;

	public WebDriver getDriver() {

		return Driver;

	}

	public void setDriver(WebDriver driver) {

		Driver = driver;

	}

	public WebElement getUserid() {

		return userid;

	}

	public void setUserid(String userid) {

		this.userid.sendKeys(userid);

	}

	public WebElement getPass() {

		return pass;

	}

	public void setPass(String pass) {

		this.pass.sendKeys(pass);

	}

	public WebElement getName() {

		return name;

	}

	public void setName(String name) {

		this.name.sendKeys(name);

	}

	public WebElement getAddress() {

		return address;

	}

	public void setAddress(String address) {

		this.address.sendKeys(address);

	}

	public WebElement getCountry() {

		return country;

	}

	public void setCountry(String country) {

		this.country.sendKeys(country);

	}

	public WebElement getZip() {

		return zip;

	}

	public void setZip(String zip) {

		this.zip.sendKeys(zip);

	}

	public WebElement getMail() {

		return mail;

	}

	public void setMail(String mail) {

		this.mail.sendKeys(mail);

	}

	public WebElement getSex() {

		return sex;

	}

	public void setSex(String sex) {

		this.sex.sendKeys(sex);

	}

	public WebElement getLanguage() {

		return language;

	}

	public void setLanguage(String language) {

		this.language.sendKeys(language);

	}

	public WebElement getSubmitbtn() {

		return submitbtn;

	}

	public void setSubmitbtn() {

		this.submitbtn.click();

	}

	public PageFactor(WebDriver driver) {

		this.Driver = driver;

		PageFactory.initElements(driver, this);

	}

}