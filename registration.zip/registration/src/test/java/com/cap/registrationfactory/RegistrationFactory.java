package com.cap.registrationfactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class RegistrationFactory {

	WebDriver driver;

	public RegistrationFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "usrID")
	@CacheLookup
	WebElement userId;

	@FindBy(id = "pwd")
	@CacheLookup
	WebElement pwd;

	@FindBy(id = "usrname")
	@CacheLookup
	WebElement useName;

	@FindBy(id = "addr")
	@CacheLookup
	WebElement address;

	@FindBy(name = "country")
	@CacheLookup
	WebElement country;

	@FindBy(name = "zip")
	@CacheLookup
	WebElement zipCode;

	@FindBy(name = "email")
	@CacheLookup
	WebElement email;

	@FindBy(name = "sex")
	@CacheLookup
	WebElement sex;

	@FindBy(name = "en")
	@CacheLookup
	WebElement langEnglish;

	@FindBy(name = "nonen")
	@CacheLookup
	WebElement langNonEnglish;

	@FindBy(id = "desc")
	@CacheLookup
	WebElement about;

	@FindBy(name = "submit")
	@CacheLookup
	WebElement submitBtn;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
		;
	}

	public WebElement getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd.sendKeys(pwd);
	}

	public WebElement getUseName() {
		return useName;
	}

	public void setUseName(String useName) {
		this.useName.sendKeys(useName);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String inputCountry) {
		Select selectCountry = new Select(country);
		selectCountry.selectByVisibleText(inputCountry);
	}

	public WebElement getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode.sendKeys(zipCode);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getSex() {
		return sex;
	}

	public void setSex() {
		this.sex.click();
	}

	public WebElement getLangEnglish() {
		return langEnglish;
	}

	public void setLangEnglish() {
		this.langEnglish.click();
	}

	public WebElement getLangNonEnglish() {
		return langNonEnglish;
	}

	public void setLangNonEnglish() {
		this.langNonEnglish.click();
	}

	public WebElement getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about.sendKeys(about);
	}

	public WebElement getSubmitBtn() {
		return submitBtn;
	}

	public void setSubmitBtn() {
		this.submitBtn.click();
	}

}
