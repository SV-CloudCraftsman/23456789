package com.cap.registration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cap.registrationfactory.RegistrationFactory;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

//Step defination file for Registration form
// Using Thread.sleep() because to see the results properly
public class RegistrationStepDefination {

	public WebDriver driver;
	public RegistrationFactory factory;

	@After
	public void Tear_Down() {
		driver.quit();
	}

	@Given("^user is on Registration Form page$")
	public void user_is_on_Registration_Form_page() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\shuvishw\\Desktop\\Chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:\\shubham\\registration\\src\\WebPages Set A\\RegistrationForm.html");
		factory = new RegistrationFactory(driver);

	}

	@Then("^verify the title 'Welcome to JobsWorld'$")
	public void verify_the_title_Welcome_to_JobsWorld() {
		String ttl = driver.getTitle();
		Assert.assertEquals("Yes, User is on Registration Form Page", "Welcome to JobsWorld", ttl);
		driver.close();
	}

	@When("^user left the User id field empty or wrong data entered$")
	public void user_left_the_User_id_field_empty_or_wrong_data_entered() {
		factory.setUserId("");
	}

	@Then("^click on submit button$")
	public void click_on_submit_button() {
		factory.setSubmitBtn();

	}

	@Then("^it will pop-up the alert box displays the message “User Id should not be empty/length be between (\\d+) to (\\d+)$")
	public void it_will_pop_up_the_alert_box_displays_the_message_User_Id_should_not_be_empty_length_be_between_to(
			int arg1, int arg2) throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "User Id should not be empty / length be between 5 to 12";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user left the Password field empty or wrong data entered$")
	public void user_left_the_Password_field_empty_or_wrong_data_entered() {
		factory.setUserId("shubham");
		factory.setPwd("");

	}

	@Then("^it will pop-up the alert box displays the message Password should not be empty/length be between (\\d+) to (\\d+)$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Password_should_not_be_empty_length_be_between_to(
			int arg1, int arg2) throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "Password should not be empty / length be between 7 to 12";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();

	}

	@When("^user left the Name field empty or wrong data entered$")
	public void user_left_the_Name_field_empty_or_wrong_data_entered() {
		factory.setUserId("shubham");
		factory.setPwd("vishwakarma");
		factory.setUseName("");
	}

	@Then("^it will pop-up the alert box displays the message Name should not be empty and must have alphabet characters only$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Name_should_not_be_empty_and_must_have_alphabet_characters_only()
			throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "Name should not be empty and must have alphabet characters only";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user left the Address field empty or wrong data entered$")
	public void user_left_the_Address_field_empty_or_wrong_data_entered() {
		factory.setUserId("shubham");
		factory.setPwd("vishwakarma");
		factory.setUseName("shubham");
		factory.setAddress("");
	}

	@Then("^it will pop-up the alert box displays the message User address must have alphanumeric characters only$")
	public void it_will_pop_up_the_alert_box_displays_the_message_User_address_must_have_alphanumeric_characters_only()
			throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "User address must have alphanumeric characters only";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user has not chosen any country from dropdown box$")
	public void user_has_not_chosen_any_country_from_dropdown_box() {
		factory.setUserId("shubham");
		factory.setPwd("vishwakarma");
		factory.setUseName("shubham");
		factory.setAddress("Chennai");
		factory.setCountry("(Please select a country)");
	}

	@Then("^it will pop-up the alert box displays the message Select your country from the list$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Select_your_country_from_the_list()
			throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "Select your country from the list";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user has given alphabests or wrong data in ZIP Code field$")
	public void user_has_given_alphabests_or_wrong_data_in_ZIP_Code_field() {
		factory.setUserId("shubham");
		factory.setPwd("vishwakarma");
		factory.setUseName("shubham");
		factory.setAddress("Chennai");
		factory.setCountry("Australia");
		factory.setZipCode("thyio");
	}

	@Then("^it will pop-up the alert box displays the message ZIP code must have numeric characters only$")
	public void it_will_pop_up_the_alert_box_displays_the_message_ZIP_code_must_have_numeric_characters_only()
			throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "ZIP code must have numeric characters only";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user has given wrong format of email id$")
	public void user_has_given_wrong_format_of_email_id() {
		factory.setUserId("shubham");
		factory.setPwd("vishwakarma");
		factory.setUseName("shubham");
		factory.setAddress("Chennai");
		factory.setCountry("Australia");
		factory.setZipCode("560060");
		factory.setEmail("shubham");

	}

	@Then("^it will pop-up the alert box displays the message You have entered an invalid email address$")
	public void it_will_pop_up_the_alert_box_displays_the_message_You_have_entered_an_invalid_email_address()
			throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "You have entered an invalid email address!";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user has not selected any gender$")
	public void user_has_not_selected_any_gender() {
		factory.setUserId("shubham");
		factory.setPwd("vishwakarma");
		factory.setUseName("shubham");
		factory.setAddress("Chennai");
		factory.setCountry("Australia");
		factory.setZipCode("560060");
		factory.setEmail("shubham@capgemini.com");
	}

	@Then("^it will pop-up the alert box displays the message Please select gender$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_select_gender() throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "Please Select gender";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user has given all information$")
	public void user_has_given_all_information() {
		factory.setUserId("shubham");
		factory.setPwd("vishwakarma");
		factory.setUseName("shubham");
		factory.setAddress("Chennai");
		factory.setCountry("Australia");
		factory.setZipCode("560060");
		factory.setEmail("shubham@capgemini.com");
		factory.setSex();
		factory.setAbout("I am a very Good boy.");
	}

	@Then("^it will pop-up the alert box$")
	public void it_will_pop_up_the_alert_box() throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage = "Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}

}
