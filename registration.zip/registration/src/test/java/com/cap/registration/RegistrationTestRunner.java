package com.cap.registration;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\shubham\\registration\\src\\test\\resources\\com\\cap\\registrationfeatures\\Registration.feature"},
		glue= {"com.cap.registration"},
		dryRun=false,
		strict=true,
		monochrome=true,
		format= {"pretty" , "html: registration-test-output"}
		
		)

//Test Runner file  
public class RegistrationTestRunner {

}
