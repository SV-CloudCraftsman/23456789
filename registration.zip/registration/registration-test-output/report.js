$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/shubham/registration/src/test/resources/com/cap/registrationfeatures/Registration.feature");
formatter.feature({
  "line": 2,
  "name": "Validating the Registration Form Fields",
  "description": "",
  "id": "validating-the-registration-form-fields",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Verify the title “Welcome to JobsWorld” of the page",
  "description": "",
  "id": "validating-the-registration-form-fields;verify-the-title-“welcome-to-jobsworld”-of-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user is on Registration Form page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "verify the title \u0027Welcome to JobsWorld\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationStepDefination.user_is_on_Registration_Form_page()"
});
