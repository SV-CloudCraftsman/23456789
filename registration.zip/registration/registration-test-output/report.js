$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/shubham/registration/src/test/resources/com/cap/registrationfeatures/Registration.feature");
formatter.feature({
  "line": 2,
  "name": "Validating the Registration Form Fields",
  "description": "",
  "id": "validating-the-registration-form-fields",
  "keyword": "Feature"
});
formatter.scenario({
  "comments": [
    {
      "line": 4,
      "value": "#this scenario will fail because title of the page is not given (negative test case)"
    }
  ],
  "line": 5,
  "name": "Verify the title “Welcome to JobsWorld” of the page",
  "description": "",
  "id": "validating-the-registration-form-fields;verify-the-title-“welcome-to-jobsworld”-of-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "user is on Registration Form page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify the title \u0027Welcome to JobsWorld\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationStepDefination.user_is_on_Registration_Form_page()"
});
formatter.result({
  "duration": 2457965900,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationStepDefination.verify_the_title_Welcome_to_JobsWorld()"
});
formatter.result({
  "duration": 38601300,
  "error_message": "org.junit.ComparisonFailure: Yes, User is on Registration Form Page expected:\u003c[Welcome to JobsWorld]\u003e but was:\u003c[]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat com.cap.registration.RegistrationStepDefination.verify_the_title_Welcome_to_JobsWorld(RegistrationStepDefination.java:38)\r\n\tat ✽.Then verify the title \u0027Welcome to JobsWorld\u0027(C:/shubham/registration/src/test/resources/com/cap/registrationfeatures/Registration.feature:7)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 853105800,
  "status": "passed"
});
formatter.scenario({
  "line": 9,
  "name": "the alert box displays the message User Id should not be empty/length be between 5 to 12 upon clicking on the button “Submit” upon wrong or no data entered in the text box",
  "description": "",
  "id": "validating-the-registration-form-fields;the-alert-box-displays-the-message-user-id-should-not-be-empty/length-be-between-5-to-12-upon-clicking-on-the-button-“submit”-upon-wrong-or-no-data-entered-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "user is on Registration Form page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "user left the User id field empty or wrong data entered",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "click on submit button",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "it will pop-up the alert box displays the message “User Id should not be empty/length be between 5 to 12",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationStepDefination.user_is_on_Registration_Form_page()"
});
formatter.result({
  "duration": 1396287500,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationStepDefination.user_left_the_User_id_field_empty_or_wrong_data_entered()"
});
formatter.result({
  "duration": 57564200,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationStepDefination.click_on_submit_button()"
});
formatter.result({
  "duration": 112091200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5",
      "offset": 97
    },
    {
      "val": "12",
      "offset": 102
    }
  ],
  "location": "RegistrationStepDefination.it_will_pop_up_the_alert_box_displays_the_message_User_Id_should_not_be_empty_length_be_between_to(int,int)"
});
